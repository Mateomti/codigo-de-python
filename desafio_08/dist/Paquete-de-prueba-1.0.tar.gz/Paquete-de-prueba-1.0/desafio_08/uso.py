import clase

alumno1 = clase.Alumno(input('Ingrese el nombre: '), int(input('Ingrese la nota: ')))
alumno1.imprimir()