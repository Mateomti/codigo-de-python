from setuptools import setup

setup(
    name = 'Paquete-de-prueba',
    version = 1.0,
    description = 'Este es un paquete de prueba',
    author = 'Mateo',
    packages = ['desafio_08']
)